function changeNameColor(id){
	document.getElementById(id).style.color = 'aqua';
}
function changeBackgroundColor(id){
	document.getElementById(id).style.background = 'lightseagreen';
}
